# Kasir Perabot — Starter Flutter

Starter aplikasi Android untuk toko perabotan rumah tangga. Versi awal mencakup:
- Data barang: tambah, edit, cari; stok, harga modal dan harga jual.
- Kasir: keranjang, diskon, metode pembayaran, validasi stok.
- Checkout disimpan secara atomik di SQLite; stok otomatis berkurang.
- Struk digital yang dapat dibagikan.
- Data pemasok dasar.
- Dashboard dan ringkasan omzet/laba kotor hari ini.

## Prasyarat
- Flutter SDK stabil
- Android Studio / Android SDK
- Perangkat Android atau emulator

## Menjalankan
1. Ekstrak ZIP.
2. Buka terminal di folder proyek.
3. Jalankan `flutter pub get`.
4. Jalankan `flutter run` untuk menguji di perangkat.
5. Untuk APK debug: `flutter build apk --debug`.
6. Untuk APK release: `flutter build apk --release` (perlu pengaturan signing sebelum distribusi resmi).

## Penting
- Ini adalah starter source code, bukan APK yang sudah dikompilasi atau diuji di perangkat.
- Cetak printer Bluetooth belum diimplementasikan; versi ini menyediakan struk digital/share.
- Sinkronisasi cloud belum diimplementasikan; database saat ini lokal/offline.
- Pembelian stok pemasok dan retur belum memengaruhi database pada starter ini.
- Lakukan pengujian menyeluruh dan pencadangan sebelum digunakan untuk transaksi nyata.
- Laporan laba saat ini merupakan estimasi sederhana; diskon dikurangkan dari laba kotor total.
- Database SQLite dibuat otomatis pada peluncuran pertama.

## Rencana lanjutan
1. Penerimaan pembelian dan stock movements yang lengkap.
2. Integrasi printer thermal Bluetooth berdasarkan model printer.
3. Backup/restore dan sinkronisasi cloud dengan ID transaksi unik.
4. Pengaturan nama toko, alamat, footer struk, dan rentang laporan.
5. Uji konsistensi stok, retur, diskon, dan migrasi database.
