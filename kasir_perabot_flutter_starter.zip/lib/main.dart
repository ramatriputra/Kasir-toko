import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:path/path.dart' as p;
import 'package:share_plus/share_plus.dart';
import 'package:sqflite/sqflite.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AppDb.instance.database;
  runApp(const KasirPerabotApp());
}

final rupiah = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp', decimalDigits: 0);
final dateFmt = DateFormat('dd-MM-yyyy HH:mm');

class KasirPerabotApp extends StatelessWidget {
  const KasirPerabotApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Kasir Perabot',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF176B52)),
          useMaterial3: true,
          inputDecorationTheme: const InputDecorationTheme(border: OutlineInputBorder()),
        ),
        home: const HomePage(),
      );
}

class AppDb {
  AppDb._();
  static final instance = AppDb._();
  Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    final path = p.join(await getDatabasesPath(), 'kasir_perabot.db');
    _db = await openDatabase(path, version: 1, onCreate: (db, version) async {
      await db.execute('''
        CREATE TABLE products(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          code TEXT NOT NULL UNIQUE,
          name TEXT NOT NULL,
          category TEXT NOT NULL DEFAULT '',
          unit TEXT NOT NULL DEFAULT 'pcs',
          cost_price INTEGER NOT NULL DEFAULT 0,
          sell_price INTEGER NOT NULL DEFAULT 0,
          stock INTEGER NOT NULL DEFAULT 0,
          min_stock INTEGER NOT NULL DEFAULT 0,
          created_at TEXT NOT NULL
        )
      ''');
      await db.execute('''
        CREATE TABLE suppliers(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          phone TEXT NOT NULL DEFAULT '',
          address TEXT NOT NULL DEFAULT '',
          notes TEXT NOT NULL DEFAULT ''
        )
      ''');
      await db.execute('''
        CREATE TABLE sales(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          invoice TEXT NOT NULL UNIQUE,
          created_at TEXT NOT NULL,
          subtotal INTEGER NOT NULL,
          discount INTEGER NOT NULL DEFAULT 0,
          total INTEGER NOT NULL,
          paid INTEGER NOT NULL,
          change_amount INTEGER NOT NULL,
          payment_method TEXT NOT NULL,
          gross_profit INTEGER NOT NULL
        )
      ''');
      await db.execute('''
        CREATE TABLE sale_items(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          sale_id INTEGER NOT NULL,
          product_id INTEGER NOT NULL,
          product_name TEXT NOT NULL,
          qty INTEGER NOT NULL,
          sell_price INTEGER NOT NULL,
          cost_price INTEGER NOT NULL,
          line_total INTEGER NOT NULL,
          FOREIGN KEY(sale_id) REFERENCES sales(id)
        )
      ''');
      await db.execute('''
        CREATE TABLE stock_movements(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          product_id INTEGER NOT NULL,
          change_qty INTEGER NOT NULL,
          reason TEXT NOT NULL,
          created_at TEXT NOT NULL
        )
      ''');
    });
    return _db!;
  }

  Future<List<Map<String, Object?>>> products() async =>
      (await database).query('products', orderBy: 'name COLLATE NOCASE');
  Future<List<Map<String, Object?>>> suppliers() async =>
      (await database).query('suppliers', orderBy: 'name COLLATE NOCASE');

  Future<void> saveProduct(Map<String, Object?> item, {int? id}) async {
    final db = await database;
    if (id == null) {
      await db.insert('products', {...item, 'created_at': DateTime.now().toIso8601String()},
          conflictAlgorithm: ConflictAlgorithm.abort);
    } else {
      await db.update('products', item, where: 'id = ?', whereArgs: [id]);
    }
  }

  Future<void> saveSupplier(Map<String, Object?> item, {int? id}) async {
    final db = await database;
    if (id == null) {
      await db.insert('suppliers', item);
    } else {
      await db.update('suppliers', item, where: 'id = ?', whereArgs: [id]);
    }
  }

  Future<List<Map<String, Object?>>> recentSales() async =>
      (await database).query('sales', orderBy: 'id DESC', limit: 100);

  Future<Map<String, int>> reportToday() async {
    final db = await database;
    final start = DateTime(DateTime.now().year, DateTime.now().month, DateTime.now().day)
        .toIso8601String();
    final rows = await db.rawQuery(
      'SELECT COALESCE(SUM(total),0) AS omzet, COALESCE(SUM(gross_profit),0) AS profit, COUNT(*) AS count FROM sales WHERE created_at >= ?',
      [start],
    );
    final row = rows.first;
    return {
      'omzet': (row['omzet'] as num).toInt(),
      'profit': (row['profit'] as num).toInt(),
      'count': (row['count'] as num).toInt(),
    };
  }

  Future<String> checkout({
    required List<CartLine> cart,
    required int discount,
    required int paid,
    required String method,
  }) async {
    final db = await database;
    final now = DateTime.now();
    final subtotal = cart.fold<int>(0, (sum, item) => sum + item.product.sellPrice * item.qty);
    final total = subtotal - discount;
    if (cart.isEmpty) throw Exception('Keranjang masih kosong.');
    if (discount < 0 || discount > subtotal) throw Exception('Diskon tidak valid.');
    if (paid < total) throw Exception('Pembayaran kurang.');
    final invoice = 'KP${DateFormat('yyMMddHHmmss').format(now)}';
    await db.transaction((txn) async {
      for (final line in cart) {
        final rows = await txn.query('products', where: 'id = ?', whereArgs: [line.product.id], limit: 1);
        if (rows.isEmpty) throw Exception('Produk ${line.product.name} tidak ditemukan.');
        final currentStock = (rows.first['stock'] as num).toInt();
        if (currentStock < line.qty) throw Exception('Stok ${line.product.name} tidak mencukupi.');
      }
      final profit = cart.fold<int>(
        0,
        (sum, item) => sum + (item.product.sellPrice - item.product.costPrice) * item.qty,
      ) - discount;
      final saleId = await txn.insert('sales', {
        'invoice': invoice,
        'created_at': now.toIso8601String(),
        'subtotal': subtotal,
        'discount': discount,
        'total': total,
        'paid': paid,
        'change_amount': paid - total,
        'payment_method': method,
        'gross_profit': profit,
      });
      for (final line in cart) {
        await txn.insert('sale_items', {
          'sale_id': saleId,
          'product_id': line.product.id,
          'product_name': line.product.name,
          'qty': line.qty,
          'sell_price': line.product.sellPrice,
          'cost_price': line.product.costPrice,
          'line_total': line.product.sellPrice * line.qty,
        });
        await txn.rawUpdate('UPDATE products SET stock = stock - ? WHERE id = ?',
            [line.qty, line.product.id]);
        await txn.insert('stock_movements', {
          'product_id': line.product.id,
          'change_qty': -line.qty,
          'reason': 'Penjualan $invoice',
          'created_at': now.toIso8601String(),
        });
      }
    });
    return invoice;
  }
}

class Product {
  final int id;
  final String code, name, category, unit;
  final int costPrice, sellPrice, stock, minStock;
  Product.fromMap(Map<String, Object?> m)
      : id = (m['id'] as num).toInt(),
        code = m['code'] as String,
        name = m['name'] as String,
        category = (m['category'] as String?) ?? '',
        unit = (m['unit'] as String?) ?? 'pcs',
        costPrice = (m['cost_price'] as num).toInt(),
        sellPrice = (m['sell_price'] as num).toInt(),
        stock = (m['stock'] as num).toInt(),
        minStock = (m['min_stock'] as num).toInt();
}

class CartLine {
  final Product product;
  int qty;
  CartLine(this.product, this.qty);
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int index = 0;
  void refresh() => setState(() {});
  @override
  Widget build(BuildContext context) {
    final pages = [
      Dashboard(onNavigate: (i) => setState(() => index = i)),
      ProductsPage(onChanged: refresh),
      const CashierPage(),
      const SuppliersPage(),
      const ReportsPage(),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('Kasir Perabot'), centerTitle: false),
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) => setState(() => index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Beranda'),
          NavigationDestination(icon: Icon(Icons.inventory_2_outlined), selectedIcon: Icon(Icons.inventory_2), label: 'Barang'),
          NavigationDestination(icon: Icon(Icons.point_of_sale_outlined), selectedIcon: Icon(Icons.point_of_sale), label: 'Kasir'),
          NavigationDestination(icon: Icon(Icons.local_shipping_outlined), selectedIcon: Icon(Icons.local_shipping), label: 'Pemasok'),
          NavigationDestination(icon: Icon(Icons.bar_chart_outlined), selectedIcon: Icon(Icons.bar_chart), label: 'Laporan'),
        ],
      ),
    );
  }
}

class Dashboard extends StatefulWidget {
  final ValueChanged<int> onNavigate;
  const Dashboard({super.key, required this.onNavigate});
  @override
  State<Dashboard> createState() => _DashboardState();
}
class _DashboardState extends State<Dashboard> {
  Map<String, int> report = {'omzet': 0, 'profit': 0, 'count': 0};
  int lowStock = 0;
  @override
  void initState() { super.initState(); load(); }
  Future<void> load() async {
    report = await AppDb.instance.reportToday();
    final products = await AppDb.instance.products();
    lowStock = products.where((p) => (p['stock'] as int) <= (p['min_stock'] as int)).length;
    if (mounted) setState(() {});
  }
  @override
  Widget build(BuildContext context) => RefreshIndicator(
    onRefresh: load,
    child: ListView(padding: const EdgeInsets.all(16), children: [
      Text('Ringkasan hari ini', style: Theme.of(context).textTheme.headlineSmall),
      const SizedBox(height: 12),
      _metric('Omzet hari ini', rupiah.format(report['omzet']), Icons.payments),
      _metric('Perkiraan laba kotor', rupiah.format(report['profit']), Icons.trending_up),
      _metric('Transaksi hari ini', '${report['count']}', Icons.receipt_long),
      _metric('Barang stok minimum', '$lowStock produk', Icons.warning_amber),
      const SizedBox(height: 12),
      FilledButton.icon(onPressed: () => widget.onNavigate(2), icon: const Icon(Icons.point_of_sale), label: const Text('Mulai transaksi')),
      OutlinedButton.icon(onPressed: () => widget.onNavigate(1), icon: const Icon(Icons.add_box_outlined), label: const Text('Tambah barang')),
      const Padding(padding: EdgeInsets.only(top: 12), child: Text('Data tersimpan di perangkat. Buat cadangan secara berkala sebelum memakai aplikasi untuk transaksi penting.', style: TextStyle(fontSize: 12))),
    ]),
  );
}
Widget _metric(String label, String value, IconData icon) => Card(
  child: ListTile(leading: Icon(icon), title: Text(label), subtitle: Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
);

class ProductsPage extends StatefulWidget {
  final VoidCallback onChanged;
  const ProductsPage({super.key, required this.onChanged});
  @override
  State<ProductsPage> createState() => _ProductsPageState();
}
class _ProductsPageState extends State<ProductsPage> {
  List<Map<String, Object?>> rows = [];
  String search = '';
  @override
  void initState() { super.initState(); load(); }
  Future<void> load() async { rows = await AppDb.instance.products(); if (mounted) setState(() {}); }
  Future<void> form([Map<String, Object?>? item]) async {
    final result = await showDialog<Map<String, Object?>>(
      context: context, builder: (_) => ProductDialog(item: item),
    );
    if (result != null) {
      try {
        await AppDb.instance.saveProduct(result, id: item?['id'] as int?);
        await load(); widget.onChanged();
      } catch (e) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Gagal menyimpan. Pastikan kode barang unik. ($e)')));
      }
    }
  }
  @override
  Widget build(BuildContext context) {
    final shown = rows.where((r) => '${r['name']} ${r['code']} ${r['category']}'.toLowerCase().contains(search.toLowerCase())).toList();
    return Column(children: [
      Padding(padding: const EdgeInsets.all(12), child: TextField(decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Cari nama atau kode barang'), onChanged: (v) => setState(() => search = v))),
      Expanded(child: shown.isEmpty ? const Center(child: Text('Belum ada barang. Tekan + untuk menambah.')) : ListView.builder(itemCount: shown.length, itemBuilder: (_, i) {
        final r = shown[i]; final stock = (r['stock'] as num).toInt(); final min = (r['min_stock'] as num).toInt();
        return ListTile(
          title: Text(r['name'] as String),
          subtitle: Text('${r['code']} · Stok $stock ${(r['unit'] as String)}${stock <= min ? ' · Stok minimum' : ''}'),
          trailing: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.end, children: [
            Text(rupiah.format(r['sell_price']), style: const TextStyle(fontWeight: FontWeight.bold)),
            Text('Modal ${rupiah.format(r['cost_price'])}', style: Theme.of(context).textTheme.bodySmall),
          ]),
          onTap: () => form(r),
        );
      })),
      Padding(padding: const EdgeInsets.all(12), child: SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: () => form(), icon: const Icon(Icons.add), label: const Text('Tambah barang')))),
    ]);
  }
}

class ProductDialog extends StatefulWidget {
  final Map<String, Object?>? item;
  const ProductDialog({super.key, this.item});
  @override
  State<ProductDialog> createState() => _ProductDialogState();
}
class _ProductDialogState extends State<ProductDialog> {
  final formKey = GlobalKey<FormState>();
  late final TextEditingController code, name, category, unit, cost, sell, stock, min;
  @override
  void initState() {
    super.initState(); final m = widget.item;
    code = TextEditingController(text: '${m?['code'] ?? ''}');
    name = TextEditingController(text: '${m?['name'] ?? ''}');
    category = TextEditingController(text: '${m?['category'] ?? ''}');
    unit = TextEditingController(text: '${m?['unit'] ?? 'pcs'}');
    cost = TextEditingController(text: '${m?['cost_price'] ?? ''}');
    sell = TextEditingController(text: '${m?['sell_price'] ?? ''}');
    stock = TextEditingController(text: '${m?['stock'] ?? '0'}');
    min = TextEditingController(text: '${m?['min_stock'] ?? '0'}');
  }
  @override
  void dispose() { for (final c in [code,name,category,unit,cost,sell,stock,min]) { c.dispose(); } super.dispose(); }
  String? requiredText(String? v) => v == null || v.trim().isEmpty ? 'Wajib diisi' : null;
  String? integer(String? v) => int.tryParse(v ?? '') == null || int.parse(v!) < 0 ? 'Masukkan angka 0 atau lebih' : null;
  @override
  Widget build(BuildContext context) => AlertDialog(
    title: Text(widget.item == null ? 'Tambah barang' : 'Edit barang'),
    content: SizedBox(width: 420, child: SingleChildScrollView(child: Form(key: formKey, child: Column(mainAxisSize: MainAxisSize.min, children: [
      TextFormField(controller: code, decoration: const InputDecoration(labelText: 'Kode barang *'), validator: requiredText),
      const SizedBox(height: 10), TextFormField(controller: name, decoration: const InputDecoration(labelText: 'Nama barang *'), validator: requiredText),
      const SizedBox(height: 10), TextFormField(controller: category, decoration: const InputDecoration(labelText: 'Kategori')),
      const SizedBox(height: 10), TextFormField(controller: unit, decoration: const InputDecoration(labelText: 'Satuan (pcs, set, dll.)'), validator: requiredText),
      const SizedBox(height: 10), TextFormField(controller: cost, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Harga modal (Rp) *'), validator: integer),
      const SizedBox(height: 10), TextFormField(controller: sell, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Harga jual (Rp) *'), validator: integer),
      const SizedBox(height: 10), TextFormField(controller: stock, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Stok awal *'), validator: integer),
      const SizedBox(height: 10), TextFormField(controller: min, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Batas stok minimum'), validator: integer),
    ])))),
    actions: [
      TextButton(onPressed: () => Navigator.pop(context), child: const Text('Batal')),
      FilledButton(onPressed: () {
        if (!formKey.currentState!.validate()) return;
        Navigator.pop(context, {
          'code': code.text.trim(), 'name': name.text.trim(), 'category': category.text.trim(),
          'unit': unit.text.trim(), 'cost_price': int.parse(cost.text), 'sell_price': int.parse(sell.text),
          'stock': int.parse(stock.text), 'min_stock': int.parse(min.text),
        });
      }, child: const Text('Simpan')),
    ],
  );
}

class CashierPage extends StatefulWidget {
  const CashierPage({super.key});
  @override
  State<CashierPage> createState() => _CashierPageState();
}
class _CashierPageState extends State<CashierPage> {
  List<Product> products = [];
  final List<CartLine> cart = [];
  String search = '';
  final discount = TextEditingController(text: '0');
  @override
  void initState() { super.initState(); load(); }
  @override
  void dispose() { discount.dispose(); super.dispose(); }
  Future<void> load() async { products = (await AppDb.instance.products()).map(Product.fromMap).toList(); if (mounted) setState(() {}); }
  int get subtotal => cart.fold(0, (s, l) => s + l.product.sellPrice * l.qty);
  int get discountValue => int.tryParse(discount.text) ?? 0;
  int get total => subtotal - discountValue;
  void add(Product p) {
    if (p.stock <= 0) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Stok barang habis.'))); return; }
    setState(() {
      final existing = cart.where((l) => l.product.id == p.id).firstOrNull;
      if (existing != null) { if (existing.qty < p.stock) existing.qty++; }
      else { cart.add(CartLine(p, 1)); }
    });
  }
  Future<void> pay() async {
    final paidCtrl = TextEditingController(text: '$total');
    String method = 'Tunai';
    final result = await showDialog<Map<String, Object?>>(context: context, builder: (ctx) => StatefulBuilder(builder: (ctx, setDialog) => AlertDialog(
      title: const Text('Pembayaran'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        ListTile(title: const Text('Total'), trailing: Text(rupiah.format(total), style: const TextStyle(fontWeight: FontWeight.bold))),
        DropdownButtonFormField<String>(value: method, decoration: const InputDecoration(labelText: 'Metode'), items: const [DropdownMenuItem(value: 'Tunai', child: Text('Tunai')), DropdownMenuItem(value: 'Transfer', child: Text('Transfer')), DropdownMenuItem(value: 'QRIS', child: Text('QRIS'))], onChanged: (v) => setDialog(() => method = v ?? 'Tunai')),
        const SizedBox(height: 12),
        TextField(controller: paidCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Uang diterima (Rp)')),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Batal')), FilledButton(onPressed: () => Navigator.pop(ctx, {'paid': int.tryParse(paidCtrl.text) ?? 0, 'method': method}), child: const Text('Simpan transaksi'))],
    )));
    paidCtrl.dispose();
    if (result == null) return;
    try {
      final invoice = await AppDb.instance.checkout(cart: cart, discount: discountValue, paid: result['paid'] as int, method: result['method'] as String);
      final paid = result['paid'] as int;
      final receipt = 'TOKO PERABOT\\nStruk: $invoice\\nTanggal: ${dateFmt.format(DateTime.now())}\\n--------------------------\\n${cart.map((l) => '${l.product.name} x${l.qty}\\n  ${rupiah.format(l.product.sellPrice * l.qty)}').join('\\n')}\\n--------------------------\\nSubtotal: ${rupiah.format(subtotal)}\\nDiskon: ${rupiah.format(discountValue)}\\nTOTAL: ${rupiah.format(total)}\\nBayar: ${rupiah.format(paid)}\\nKembali: ${rupiah.format(paid-total)}\\nTerima kasih.';
      if (!mounted) return;
      setState(() { cart.clear(); discount.text = '0'; });
      await load();
      await Navigator.push(context, MaterialPageRoute(builder: (_) => ReceiptPage(text: receipt)));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Transaksi gagal: $e')));
    }
  }
  @override
  Widget build(BuildContext context) {
    final shown = products.where((p) => '${p.name} ${p.code}'.toLowerCase().contains(search.toLowerCase())).toList();
    return Column(children: [
      Padding(padding: const EdgeInsets.all(12), child: TextField(decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Cari barang untuk dijual'), onChanged: (v) => setState(() => search = v))),
      SizedBox(height: 130, child: shown.isEmpty ? const Center(child: Text('Tambahkan barang terlebih dahulu.')) : ListView.builder(itemCount: shown.length, itemBuilder: (_, i) {
        final p = shown[i]; return ListTile(title: Text(p.name), subtitle: Text('${p.code} · Stok ${p.stock}'), trailing: Text(rupiah.format(p.sellPrice)), onTap: () => add(p));
      })),
      const Divider(),
      Padding(padding: const EdgeInsets.symmetric(horizontal: 12), child: Row(children: [const Expanded(child: Text('Keranjang', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))), Text('${cart.length} jenis barang')])),
      Expanded(child: cart.isEmpty ? const Center(child: Text('Pilih barang di atas untuk mulai.')) : ListView.builder(itemCount: cart.length, itemBuilder: (_, i) {
        final line = cart[i]; return ListTile(
          title: Text(line.product.name), subtitle: Text('${rupiah.format(line.product.sellPrice)} × ${line.qty}'),
          leading: IconButton(icon: const Icon(Icons.remove_circle_outline), onPressed: () => setState(() { line.qty--; if (line.qty <= 0) cart.removeAt(i); })),
          trailing: Row(mainAxisSize: MainAxisSize.min, children: [
            IconButton(icon: const Icon(Icons.add_circle_outline), onPressed: () => setState(() { if (line.qty < line.product.stock) line.qty++; })),
            IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => setState(() => cart.removeAt(i))),
          ]),
        );
      })),
      Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: Theme.of(context).colorScheme.surfaceContainer, border: const Border(top: BorderSide(color: Colors.black12))), child: Column(children: [
        TextField(controller: discount, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Diskon total (Rp)'), onChanged: (_) => setState(() {})),
        const SizedBox(height: 8), Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('Total'), Text(rupiah.format(total), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 22))]),
        const SizedBox(height: 8), SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: cart.isEmpty || discountValue < 0 || discountValue > subtotal ? null : pay, icon: const Icon(Icons.payment), label: const Text('Bayar & buat struk'))),
      ])),
    ]);
  }
}

class ReceiptPage extends StatelessWidget {
  final String text;
  const ReceiptPage({super.key, required this.text});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Struk transaksi')),
    body: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
      Expanded(child: Container(width: double.infinity, padding: const EdgeInsets.all(16), color: Colors.white, child: SingleChildScrollView(child: SelectableText(text, style: const TextStyle(fontFamily: 'monospace', color: Colors.black))))),
      const SizedBox(height: 12),
      SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: () => Share.share(text, subject: 'Struk Kasir Perabot'), icon: const Icon(Icons.share), label: const Text('Bagikan / simpan struk'))),
      const SizedBox(height: 8),
      const Text('Cetak Bluetooth akan ditambahkan pada tahap integrasi printer.', style: TextStyle(fontSize: 12)),
    ])),
  );
}

class SuppliersPage extends StatefulWidget {
  const SuppliersPage({super.key});
  @override
  State<SuppliersPage> createState() => _SuppliersPageState();
}
class _SuppliersPageState extends State<SuppliersPage> {
  List<Map<String, Object?>> rows = [];
  @override
  void initState() { super.initState(); load(); }
  Future<void> load() async { rows = await AppDb.instance.suppliers(); if (mounted) setState(() {}); }
  Future<void> addSupplier() async {
    final name = TextEditingController(), phone = TextEditingController(), address = TextEditingController();
    final result = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Tambah pemasok'),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: name, decoration: const InputDecoration(labelText: 'Nama pemasok *')),
        const SizedBox(height: 10), TextField(controller: phone, decoration: const InputDecoration(labelText: 'Nomor telepon')),
        const SizedBox(height: 10), TextField(controller: address, decoration: const InputDecoration(labelText: 'Alamat')),
      ])),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Simpan'))],
    ));
    if (result == true && name.text.trim().isNotEmpty) {
      await AppDb.instance.saveSupplier({'name': name.text.trim(), 'phone': phone.text.trim(), 'address': address.text.trim(), 'notes': ''});
      await load();
    }
    name.dispose(); phone.dispose(); address.dispose();
  }
  @override
  Widget build(BuildContext context) => Column(children: [
    Expanded(child: rows.isEmpty ? const Center(child: Text('Belum ada data pemasok.')) : ListView(children: rows.map((r) => ListTile(leading: const Icon(Icons.local_shipping_outlined), title: Text(r['name'] as String), subtitle: Text('${r['phone']}\\n${r['address']}'))).toList())),
    Padding(padding: const EdgeInsets.all(12), child: SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: addSupplier, icon: const Icon(Icons.add), label: const Text('Tambah pemasok')))),
  ]);
}

class ReportsPage extends StatefulWidget {
  const ReportsPage({super.key});
  @override
  State<ReportsPage> createState() => _ReportsPageState();
}
class _ReportsPageState extends State<ReportsPage> {
  Map<String, int> report = {'omzet': 0, 'profit': 0, 'count': 0};
  List<Map<String, Object?>> sales = [];
  @override
  void initState() { super.initState(); load(); }
  Future<void> load() async { report = await AppDb.instance.reportToday(); sales = await AppDb.instance.recentSales(); if (mounted) setState(() {}); }
  @override
  Widget build(BuildContext context) => RefreshIndicator(onRefresh: load, child: ListView(padding: const EdgeInsets.all(12), children: [
    Text('Laporan hari ini', style: Theme.of(context).textTheme.headlineSmall),
    _metric('Omzet', rupiah.format(report['omzet']), Icons.payments),
    _metric('Perkiraan laba kotor', rupiah.format(report['profit']), Icons.trending_up),
    _metric('Jumlah transaksi', '${report['count']}', Icons.receipt_long),
    const SizedBox(height: 12), Text('Transaksi terbaru', style: Theme.of(context).textTheme.titleLarge),
    if (sales.isEmpty) const Padding(padding: EdgeInsets.all(20), child: Text('Belum ada transaksi.'))
    else ...sales.map((s) => ListTile(
      title: Text('${s['invoice']} · ${rupiah.format(s['total'])}'),
      subtitle: Text('${dateFmt.format(DateTime.parse(s['created_at'] as String))} · ${s['payment_method']}'),
      trailing: Text(rupiah.format(s['gross_profit']), style: const TextStyle(fontSize: 12)),
    )),
    const Padding(padding: EdgeInsets.only(top: 12), child: Text('Laba yang ditampilkan adalah estimasi laba kotor. Laporan periode khusus, biaya operasional, retur, dan laporan pembelian akan dikembangkan berikutnya.', style: TextStyle(fontSize: 12))),
  ]));
}
