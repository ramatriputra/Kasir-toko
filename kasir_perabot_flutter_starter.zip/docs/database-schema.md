# Skema inti (SQLite)

## products
- id INTEGER PRIMARY KEY AUTOINCREMENT
- code TEXT UNIQUE NOT NULL
- name TEXT NOT NULL
- category TEXT
- unit TEXT
- cost_price INTEGER
- sell_price INTEGER
- stock INTEGER
- min_stock INTEGER
- created_at TEXT

## sales
- id INTEGER PRIMARY KEY AUTOINCREMENT
- invoice TEXT UNIQUE NOT NULL
- created_at TEXT
- subtotal INTEGER
- discount INTEGER
- total INTEGER
- paid INTEGER
- change_amount INTEGER
- payment_method TEXT
- gross_profit INTEGER

## sale_items
- id INTEGER PRIMARY KEY AUTOINCREMENT
- sale_id INTEGER
- product_id INTEGER
- product_name TEXT
- qty INTEGER
- sell_price INTEGER
- cost_price INTEGER
- line_total INTEGER

## suppliers
- id INTEGER PRIMARY KEY AUTOINCREMENT
- name TEXT
- phone TEXT
- address TEXT
- notes TEXT

## stock_movements
- id INTEGER PRIMARY KEY AUTOINCREMENT
- product_id INTEGER
- change_qty INTEGER
- reason TEXT
- created_at TEXT
